"""
Useful utilities for forming approximations.
"""