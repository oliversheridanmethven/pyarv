# ARV

C library implementing approximate random variables.   
 
