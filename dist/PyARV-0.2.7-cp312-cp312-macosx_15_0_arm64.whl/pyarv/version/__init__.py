"""
Version information.
"""

from pyarv.version.version_bindings import *

__version__: str = repo_version()
__version__: str
"""The repo's version"""