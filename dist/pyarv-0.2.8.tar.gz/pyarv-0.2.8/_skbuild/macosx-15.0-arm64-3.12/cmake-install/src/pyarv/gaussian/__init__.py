"""
The Gaussian distribution, a.k.a. the Normal distribution.  
"""