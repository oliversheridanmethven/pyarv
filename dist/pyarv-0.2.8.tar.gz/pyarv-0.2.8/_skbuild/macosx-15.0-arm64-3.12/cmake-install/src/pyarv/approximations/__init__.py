r"""
The general framework for our approximations.  
"""