# Error codes

A basic library to introduce error codes and some associated 
functionality. Unfortunately, the C type safety for using 
these is not perfect.