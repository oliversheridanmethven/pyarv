# Logging



A simple logging library. This is a wrapper around the
[GLib](https://docs.gtk.org/glib/logging.html) library.