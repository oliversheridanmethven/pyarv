# Installation

To install the latest version run:

```bash
pip install git+https://github.com/oliversheridanmethven/pyarv.git
```

To test the installation is working fine run:
```bash
pytest --pyargs pyarv
```