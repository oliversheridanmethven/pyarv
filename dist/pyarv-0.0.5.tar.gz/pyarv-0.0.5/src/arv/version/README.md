# Version



This is a small header onlly library which can be included
to retreive info about the version of this repository. 