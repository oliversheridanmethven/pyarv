# Testing

A library providing a unit testing framework.
The underlying C testing framework uses [Criterion](https://criterion.readthedocs.io/),
and for Python unittest.

