static void empty_function_for_iso_non_empty_translation_unit(void) {}
