"""
The PyARV suite for approximate random variables. 
"""

# from pyarv._version import repo_version
# 
# __version__ = repo_version()
