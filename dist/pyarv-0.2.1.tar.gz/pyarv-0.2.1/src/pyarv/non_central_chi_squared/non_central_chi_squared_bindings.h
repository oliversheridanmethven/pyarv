#ifndef PYARV_NON_CENTRAL_CHI_SQUARED_BINDINGS_H
#define PYARV_NON_CENTRAL_CHI_SQUARED_BINDINGS_H

#define PY_SSIZE_T_CLEAN
#include <Python.h>

PyObject *linear_(PyObject *Py_UNUSED(self), PyObject *args, PyObject *kwargs);

#endif//PYARV_NON_CENTRAL_CHI_SQUARED_BINDINGS_H
