"""
The non-central \( \chi^2 \) distribution.
"""