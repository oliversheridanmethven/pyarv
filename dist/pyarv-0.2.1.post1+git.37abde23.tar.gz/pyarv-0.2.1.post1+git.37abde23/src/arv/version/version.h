#ifndef REPO_VERSION_H_
#define REPO_VERSION_H_

char *repo_name(void);

char *repo_version(void);

char *repo_author(void);

char *repo_email(void);

#endif  /* REPO_VERSION_H_ */
