#!/bin/bash

export PYTHONPATH=$PWD/src:$PYTHONPATH
