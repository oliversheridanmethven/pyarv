"""
The Gaussian distribution.
"""