#ifndef TESTING_HELLO_WORLD_HPP
#define TESTING_HELLO_WORLD_HPP

void hello_world(void);

#endif //TESTING_HELLO_WORLD_HPP
