#include "hello_world.hpp"
#include <iostream>

void hello_world(void) {
    std::cout << "Hello world." << std::endl;
}
