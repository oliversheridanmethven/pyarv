#include "hello_world.hpp"

int main(int argc, char **argv) {
    hello_world();
}
