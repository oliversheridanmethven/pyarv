#ifndef TESTING_SEED_HPP
#define TESTING_SEED_HPP

namespace rubiks
{
    namespace shufflers
    {
        using Seed = std::optional<int>;

    }
}// namespace rubiks
#endif//TESTING_SEED_HPP
